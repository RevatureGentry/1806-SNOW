angular.module('c-app').controller('catalog-controller',[function($scope,dataService,$interval){
    $scope.refresh = function(){
        $scope.getAllUsers();
    }

    $scope.getAllUsers = function(){
        dataService.getUsers().then(function(value){
            $scope.items = value.data;
        });
    }
}]);